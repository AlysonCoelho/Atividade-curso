import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class LImpadorDeTexto {

    public static void main(String[] args) throws FileNotFoundException {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Olá, eu sou o Limpador de texto!!! "
                + "Onde está o arquivo texto que devo limpar?");
        String caminhoPasta = scanner.nextLine();

        File pasta = new File(caminhoPasta);

        if (pasta.exists() && pasta.isDirectory()) {
            System.out.println("Muito bom, entendi. O arquivo está em: " + caminhoPasta
                    
            		+ " Qual é o nome do arquivo texto que devo limpar?");

            String nomeArquivo = scanner.nextLine();
            File Arquivo = new File(pasta, nomeArquivo);

            try {
                Scanner leitorArquivo = new Scanner(Arquivo);

                System.out.println("Conteúdo do arquivo texto:");
                while (leitorArquivo.hasNextLine()) {
                    String linha = leitorArquivo.nextLine();
                    System.out.println(linha);
                }

                leitorArquivo.close();

            } catch (FileNotFoundException e) {
                
                System.out.println("Certo. O arquivo é: " + nomeArquivo
                        + " Agora me informe o que devo limpar dentro do arquivo. Quando você deixar em branco, vou entender que posso iniciar a limpeza.");

                String palavra1 = scanner.nextLine();
                String palavra2 = scanner.nextLine();

                System.out.println("Boa, já tenho tudo que preciso.");
                System.out.println("Vou limpar \"" + palavra1 + "\" e \"" + palavra2 + "\".");

                limparArquivo(Arquivo, palavra1, palavra2);

                System.out.println("Terminei. Dá uma olhada lá.");

            }
        } else {
            System.out.println("Caminho inválido ou não é uma pasta.");
        }

        scanner.close();
    }

    private static void limparArquivo(File arquivo, String palavra1, String palavra2) throws FileNotFoundException {
        File novoArquivo = new File(arquivo.getParent(), "jogo_turma2_" + arquivo.getName());

        try (Scanner leitorArquivo = new Scanner(arquivo); PrintWriter escritorArquivo = new PrintWriter(novoArquivo)) {

            while (leitorArquivo.hasNextLine()) {
                String linha = leitorArquivo.nextLine();
                String linhaLimpa = linha.replaceAll(palavra1, "").replaceAll(palavra2, "");
                escritorArquivo.println(linhaLimpa);

}

    }
}
}
